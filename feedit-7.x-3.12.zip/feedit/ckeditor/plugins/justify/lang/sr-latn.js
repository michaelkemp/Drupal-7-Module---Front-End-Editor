/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'sr-latn', {
	block: 'Obostrano ravnanje',
	center: 'Centriran tekst',
	left: 'Levo ravnanje',
	right: 'Desno ravnanje'
} );
